<?php

namespace Drupal\features\Exception;

class InvalidArgumentException extends \InvalidArgumentException {

}
