# Simple Oauth Extend

Adds user id to the Simple Oauth response for Drupal 8.

## Credits
- https://www.drupal.org/u/reszli for the code example.